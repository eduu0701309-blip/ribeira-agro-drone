RIBEIRA AGRO DRONE — PWA / PROTÓTIPO DE TCC

Arquivos:
- index.html — aplicativo
- manifest.webmanifest — configuração de instalação
- service-worker.js — funcionamento offline/cache
- icon-192.png e icon-512.png — ícones do aplicativo

IMPORTANTE:
Para instalar como PWA em celular, o projeto precisa ser servido por HTTPS (ou localhost).
Abrir o HTML diretamente como arquivo funciona para demonstração, mas a instalação PWA normalmente exige um servidor.

Credenciais demonstrativas:
E-mail: produtor@ribeiraagro.com
Senha: 123456

Os dados e a IA são simulados para apresentação acadêmica.
